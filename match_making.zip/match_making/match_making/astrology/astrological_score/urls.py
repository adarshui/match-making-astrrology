from django.urls import path
from . import views

urlpatterns = [
    path('api/astrological-details', views.calculate_astrological_details, name='calculate_astrological_details'),
    path('',views.index,name='index')
]