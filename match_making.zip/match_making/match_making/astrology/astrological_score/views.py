# astrological_details/views.py

import requests
from django.http import JsonResponse
from django.shortcuts import render


def index(request):
    return render(request,'index.html')

from datetime import datetime

def extract_date_month_year(date_of_birth):
    # Parse the date of birth string into a datetime object
    dob_datetime = datetime.strptime(date_of_birth, "%Y-%m-%d")
    
    # Extract the date, month, and year
    date = dob_datetime.day
    month = dob_datetime.month
    year = dob_datetime.year
    
    return date, month, year


def extract_hour_minute(birth_time):
    # Parse the birth time string into a datetime object
    birth_time_datetime = datetime.strptime(birth_time, "%H:%M")
    
    # Extract the hour and minute
    hour = birth_time_datetime.hour
    minute = birth_time_datetime.minute
    
    return hour, minute


def geo_coding_api(city):
    url = "https://forward-reverse-geocoding.p.rapidapi.com/v1/search"

    querystring = {"q":city,"accept-language":"en","polygon_threshold":"0.0"}

    headers = {
        "X-RapidAPI-Key": "c7bdb687bamsh5b871ae94dec1cbp15ff4fjsnf7b172445e64",
        "X-RapidAPI-Host": "forward-reverse-geocoding.p.rapidapi.com"
    }

    response = requests.get(url, headers=headers, params=querystring)
    data=(response.json())
    latitude = float(data[0]['lat'])
    longitude = float(data[0]['lon'])

    return latitude,longitude
def calculate_astrological_details(request):
    if request.method == 'POST':
        male_name = request.POST.get('maleName')
        print(request.POST)
        print(male_name)
        female_name = request.POST.get('femaleName')
        print(request.POST.get('maleBirthDate'))
        male_date,male_month,male_year = extract_date_month_year(request.POST.get('maleBirthDate'))
        male_birth_hour,male_birth_minute = extract_hour_minute(request.POST.get('maleBirthTime'))
        male_birth_lat,male_lang = geo_coding_api(request.POST.get('maleBirthPlace'))
        female_date,female_month,female_year = extract_date_month_year(request.POST.get('femaleBirthDate'))
        female_birth_hour,female_birth_minute = extract_hour_minute(request.POST.get('femaleBirthTime'))
        female_birth_lat,female_birth_lang = geo_coding_api(request.POST.get('femaleBirthPlace'))

        # Call the astrological API with the provided data
        try:
            url = "https://astrologer.p.rapidapi.com/api/v4/relationship-score"
            payload = {
            "first_subject": {
                "name": male_name,
                "year": male_year,
                "month": male_month,
                "day": male_date,
                "hour": male_birth_hour,
                "minute": male_birth_minute,
                "longitude":male_lang ,
                "latitude": male_birth_lat,
                "city": request.POST.get('maleBirthPlace'),
                "timezone": "Asia/Kolkata"
            },
            "second_subject": {
                "name": female_name,
                "year": female_year,
                "month": female_month,
                "day": female_date,
                "hour": female_birth_hour,
                "minute": female_birth_minute,
                "longitude": female_birth_lang,
                "latitude": female_birth_lat,
                "city": request.POST.get('femaleBirthPlace'),
                "timezone": "Asia/Kolkata"
            }
        }
            headers = {
                "content-type": "application/json",
                "X-RapidAPI-Key": "c7bdb687bamsh5b871ae94dec1cbp15ff4fjsnf7b172445e64",
                "X-RapidAPI-Host": "astrologer.p.rapidapi.com"
            }
            response = requests.post(url, json=payload, headers=headers) 
            data = response.json()
            # Process the response as needed
            print(data)
            astrological_score = data.get('score', 'N/A')

            return JsonResponse({'success': True, 'astrological_score': astrological_score})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)
    else:
        return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=400)
