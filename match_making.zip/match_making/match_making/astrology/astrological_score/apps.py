from django.apps import AppConfig


class AstrologicalScoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'astrological_score'
